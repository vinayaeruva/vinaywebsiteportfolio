gsap.registerPlugin(SplitText, CustomEase);

const tl = gsap.timeline({
  defaults: {
    ease: CustomEase.create("custom", "0.77, 0, 0.175, 1"),
    duration: 1,
  },
});

const splitOne = new SplitText(".headline-1", { type: "chars" });
const splitTwo = new SplitText(".headline-2", { type: "chars" });
const splitThree = new SplitText(".headline-3", { type: "chars" });

tl.fromTo(
  ".loader-screen",
  { clipPath: "inset(0 0 0% 0)" },
  { clipPath: "inset(0 0 100% 0)", delay: 1 }
)
  .from(".header", { y: "-100%" }, "-=0.25")
  .from(
    [splitOne.chars, splitTwo.chars, splitThree.chars],
    {
      duration: 0.5,
      y: 150,
      opacity: 0,
      stagger: 0.03,
    },
    "-=0.20"
  )
  .from(
    ".explore-catalog-btn",
    {
      scale: 1.1,
      opacity: 0,
    },
    "<"
  )
  .from(
    ".arrow-circle",
    {
      x: -50,
      y: 50,
      opacity: 0,
    },
    "<"
  )
  .from(
    ".landing-paragraph",
    {
      x: -20,
      opacity: 0,
    },
    "<"
  )
  .from(
    ".separator",
    {
      scaleX: 0,
      opacity: 0,
    },
    "<"
  )
  .from(
    ".label-line",
    {
      scaleX: 0,
    },
    "<"
  )
  .from(
    [".certs-1", ".certs-2"],
    {
      opacity: 0,
      stagger: 0.01,
      x: -20,
    },
    "<"
  )
  .from(
    ".scroll-down-indicator span",
    {
      y: 20,
      opacity: 0,
    },
    "<"
  )
  .from(
    ".scroll-down-indicator img",
    {
      y: 20,
      opacity: 0,
    },
    "<"
  );
